# Redux Intro

Follow along in the companion blog post to learn how Redux works:
[https://daveceddia.com/how-does-redux-work/](https://daveceddia.com/how-does-redux-work/)

---

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

You can find the most recent version of the Create React App README [here](https://github.com/facebookincubator/create-react-app/blob/master/packages/react-scripts/template/README.md).
